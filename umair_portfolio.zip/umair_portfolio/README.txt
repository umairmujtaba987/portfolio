Umair Mujtaba — Portfolio
Files:
- index.html (main page with CSS-only theme toggle, typewriter editor, skill bars)
- projects.html (dedicated projects page that loads projects.json)
- style.css (styles including CSS-only toggle and animations)
- projects.json (example projects list)
- hero.svg (decorative hero SVG placeholder)
- README.txt (this file)

To use:
1. Extract files into the root of your GitHub Pages repo (or a folder).
2. Replace placeholder links (email, GitHub, LinkedIn) and add resume.pdf if you want.
3. Edit projects.json to add your real projects.
4. Commit & push to GitHub. Enable GitHub Pages on the repo (branch main, root).
